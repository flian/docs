==============================================================================
Endeca Developer Studio

GENERAL (6.1.2) 

    - Release Date: March 2012

    - The release notes may have been updated since the release date. 
      Contact Oracle Endeca Customer Support for the most recent version
      of the release notes.
      
==============================================================================

GENERAL (6.1.1) 

    - Release Date: December 2011

    - The release notes may have been updated since the release date. 
      Access the Product Downloads section of the Endeca Developer Network 
      (EDeN) at https://eden.endeca.com for the most recent version of the 
      release notes.


KNOWN ISSUES (6.1.1)

    - Loading a large (e.g. 1GB or larger) dimensions.xml file into Developer
      Studio causes Developer Studio to fail. This condition typically occurs
      when dimensions are maintained outside Developer Studio. Under these
      circumstances, there is a workaround that requires the following steps: 

      1. Use Developer Studio to construct an empty shell file for
         dimensions.xml, including definitions for dimensions that will be
         maintained by an external process. These dimensions should have no
         values defined in Developer Studio. Store this file with the other
         instance configuration files that Developer Studio manages. For
         example, when using the Deployment Template, you would store this
         stub file in [appdir]/config/pipeline/dimensions.xml. Note that you
         can now use Developer Studio to assign mappings to the empty stub
         dimensions you define.

      2. Generate the large dimensions.xml file to a different directory from
         the stub dimension file. For example, when using the Deployment
         Template, you might use your baseline update script to generate
         dimensions.xml in [appdir]/data/generated_data/dimensions.xml. If you
         intend to overwrite the stub dimensions.xml file with the large,
         script-generated dimensions.xml file, you may need to configure
         scripts used to generate the large dimensions to assign the same
         dimension IDs as the ones specified for the stub dimensions in
         Developer Studio. 

      3. Overwrite or merge the empty stub file with the large dimensions.xml
         file and then modify the baseline update script to run Forge against
         the merged file. For example, you might merge [appdir]
         /config/pipeline/dimensions.xml with [appdir]
         /data/generated_data/dimensions.xml and save the result to [appdir
         /data/complete_index_config/dimensions.xml.

==============================================================================
Endeca Developer Studio

GENERAL (6.1.0)

    - Release Date: March 2010
  
    - The release notes may have been updated since the release date. 
      Access the Product Downloads section of the Endeca Developer Network 
      (EDeN) at https://eden.endeca.com for the most recent version of the 
      release notes.. 


INSTALLATION (6.1.0)

    - Refer to the Endeca Developer Studio Installation Guide for installation
      information.


MIGRATION (6.1.0)

    - Refer to the Endeca Platform Services Migration Guide for information
      specific to Developer Studio migration.    


BUG FIXES (6.1.0)
      
    - None


KNOWN ISSUES (6.1.0)

    - Loading a large (e.g. 1GB or larger) dimensions.xml file into Developer
      Studio causes Developer Studio to fail. This condition typically occurs
      when dimensions are maintained outside Developer Studio. Under these
      circumstances, there is a workaround that requires the following steps: 

      1. Use Developer Studio to construct an empty shell file for
         dimensions.xml, including definitions for dimensions that will be
         maintained by an external process. These dimensions should have no
         values defined in Developer Studio. Store this file with the other
         instance configuration files that Developer Studio manages. For
         example, when using the Deployment Template, you would store this
         stub file in [appdir]/config/pipeline/dimensions.xml. Note that you
         can now use Developer Studio to assign mappings to the empty stub
         dimensions you define.

      2. Generate the large dimensions.xml file to a different directory from
         the stub dimension file. For example, when using the Deployment
         Template, you might use your baseline update script to generate
         dimensions.xml in [appdir]/data/generated_data/dimensions.xml. If you
         intend to overwrite the stub dimensions.xml file with the large,
         script-generated dimensions.xml file, you may need to configure
         scripts used to generate the large dimensions to assign the same
         dimension IDs as the ones specified for the stub dimensions in
         Developer Studio. 

      3. Overwrite or merge the empty stub file with the large dimensions.xml
         file and then modify the baseline update script to run Forge against
         the merged file. For example, you might merge [appdir]
         /config/pipeline/dimensions.xml with [appdir]
         /data/generated_data/dimensions.xml and save the result to [appdir
         /data/complete_index_config/dimensions.xml.

==============================================================================